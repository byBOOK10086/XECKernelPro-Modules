#!/system/bin/sh
# 示例模块：开机后写一行标记，证明模块被加载、脚本被执行。
# 模块脚本约定：MODDIR=${0%/*} 指向模块自己的目录（Magisk/KernelSU 通用）。
MODDIR=${0%/*}
echo "$(date '+%F %T') xecpro-sample loaded (MODDIR=$MODDIR)" >> /data/local/tmp/xecpro-sample.log
