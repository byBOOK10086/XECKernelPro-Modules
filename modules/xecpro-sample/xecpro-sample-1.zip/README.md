XEC 示例模块
=============

这是个**模板**：把它解压，改 module.prop 里的 id/name/version/versionCode/description，
把你的文件按 system/ 目录结构放进去，重新打包成 zip（module.prop 必须在 zip 根目录），
然后按仓库 README 的方式提交（issue 表单或你自己的 GitHub Release）。

包含：
  module.prop   模块元数据（id/name/version/versionCode/author/description）
  service.sh    开机 late_start 阶段执行；这里只写一行日志证明链路通
